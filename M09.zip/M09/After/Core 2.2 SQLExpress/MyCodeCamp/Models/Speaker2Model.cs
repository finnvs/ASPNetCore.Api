﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyCodeCamp.Models
{
    public class Speaker2Model : SpeakerModel
    {
        // adding a 'view prop' to the existing model
        public string BadgeName { get; set; }
    }
}
