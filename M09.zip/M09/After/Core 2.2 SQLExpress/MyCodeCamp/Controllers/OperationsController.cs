﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;

namespace MyCodeCamp.Controllers
{
    /// <summary>
    /// Code changed from video series with target .Net Core 1.0, 
    /// in order to build against .Net Core 2.2. See url:
    /// https://app.pluralsight.com/player?course=building-api-aspdotnet-core&author=shawn-wildermuth&name=395a0110-ea96-45da-a086-8e8ce3496049&clip=2&mode=live
    /// </summary>
    [Route("api/[controller]")]
    public class OperationsController : ControllerBase
    {        
        private ILogger _logger;
        private readonly IConfiguration _config;

        public OperationsController(ILogger<OperationsController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _config = configuration;
        }

        [HttpOptions("reloadConfig")]
        public IActionResult ReloadConfig()
        {
            try
            {
                var root = (IConfigurationRoot)_config;
                root.Reload();
                return Ok("Configuration was successfully reloaded");
            }
            catch (Exception ex)
            {
                var errMsg = ex.Message;
                _logger.LogError($"Threw exception while reloading configuration: { errMsg }");
                

            }
            return BadRequest("Could not reload configuration");
            // return this.StatusCode(StatusCodes.Status500InternalServerError);
        }
    }
}
