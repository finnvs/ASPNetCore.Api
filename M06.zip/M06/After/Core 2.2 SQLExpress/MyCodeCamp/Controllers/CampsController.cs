﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyCodeCamp.Data;
using MyCodeCamp.Data.Entities;
using MyCodeCamp.Filters;
using MyCodeCamp.Models;

namespace MyCodeCamp.Controllers
{
    [Route("api/[controller]")]
    [ValidateModel]
    public class CampsController : BaseController
    {
        private ICampRepository _repo;
        private ILogger<CampsController> _logger;
        private IMapper _mapper;

        public CampsController(ICampRepository repo, 
            ILogger<CampsController> logger,
            IMapper mapper)
        {
            _repo = repo;
            _logger = logger;
            _mapper = mapper;
        }

        [HttpGet("")]
        public IActionResult Get()
        {
            var camps = _repo.GetAllCamps();

            return Ok(_mapper.Map<IEnumerable<CampModel>>(camps));
        }

        [HttpGet("{moniker}", Name = "CampGet")]
        public IActionResult Get(string moniker, bool includeSpeakers = false)
        {
            try
            {
                Camp camp = null;

                if (includeSpeakers) camp = _repo.GetCampByMonikerWithSpeakers(moniker);
                else camp = _repo.GetCampByMoniker(moniker);
                if (camp == null) return NotFound($"Camp {moniker} was not found");
                return Ok(_mapper.Map<CampModel>(camp));
            }
            catch (Exception ex)
            {
                var errMsg = ex.Message;
                _logger.LogError($"Threw exception while getting Camp: { ex }");              

            }
            return BadRequest($"Failed to get Camp with moniker: { moniker } ");

        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody]CampModel model)
        {
            try
            {
                _logger.LogInformation("Creating a new Code Camp");

                var camp = _mapper.Map<Camp>(model);

                // We need to ensure that values for both location and eventdate 
                // are set with default values, if they are passed as null
                if(camp.Location == null)
                {
                    camp.Location = new Location()
                    {
                        Address1 = "123 Main Street",
                        CityTown = "Atlanta",
                        StateProvince = "GA",
                        PostalCode = "30303",
                        Country = "USA"
                    };
                };

                if(camp.EventDate == null)
                {
                    camp.EventDate = DateTime.Now;
                };

                // Also, if a POST comes in without a Name, a Moniker or a Description, set defaults
                // in order to accomodate the later GET and PUT examples given in the video
                                
                if (camp.Name == null)
                {
                    camp.Name = "No Name Code Camp";
                };

                if (camp.Moniker == null)
                {
                    camp.Moniker = "AtoZMoniker123";
                };

                if (camp.Description == null)
                {
                    camp.Description = "No Name Code Camp Description";
                };


                _repo.Add(camp);
                if(await _repo.SaveAllAsync())
                {
                    var newUri = Url.Link("CampGet", new { moniker = camp.Moniker });
                    return Created(newUri, _mapper.Map<CampModel>(camp));
                }
                else
                {
                    _logger.LogWarning("Could not save Camp to database");
                }

            }
            catch (Exception ex)
            {
                var errMsg = ex.Message;
                _logger.LogError($"Threw exception while saving Camp: { ex }");
                return BadRequest(errMsg);
            }

            return BadRequest();
        }

        [HttpPut("{moniker}")]
        public async Task<IActionResult> Put(string moniker, [FromBody]CampModel model)
        {
            try
            {               
                var oldCamp = _repo.GetCampByMoniker(moniker);
                if (oldCamp == null)
                    return NotFound($"Could not find a camp with moniker { moniker }");

                _mapper.Map(model, oldCamp);

                if ( await _repo.SaveAllAsync())
                {
                    return Ok(_mapper.Map<CampModel>(oldCamp));
                }
            }
            catch(Exception ex)
            {
                var errMsg = ex.Message;
                _logger.LogError($"Threw exception while saving Camp: { ex }");
                return BadRequest(errMsg);
            }

            return BadRequest("Could not update Camp");
        }

        [HttpDelete("{moniker}")]
        public async Task<IActionResult> Delete(string moniker)
        {
            try
            {
                var oldCamp = _repo.GetCampByMoniker(moniker);
                if (oldCamp == null)
                    return NotFound($"Could not find a camp with a moniker of { moniker }");
                _repo.Delete(oldCamp);
                
                if (await _repo.SaveAllAsync())
                {
                    return Ok("Camp was deleted");
                }
            }
            catch (Exception ex)
            {
                var errMsg = ex.Message;
                _logger.LogError($"Threw exception while deleting camp: { errMsg }");                
            }
            return BadRequest("Could not delete camp");
        }

    }
}