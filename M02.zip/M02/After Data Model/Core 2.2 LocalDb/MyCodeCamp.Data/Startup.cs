﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MyCodeCamp.Data.Entities;

namespace MyCodeCamp.Data
{
  public class Startup
  {
     public Startup(IConfiguration configuration)
     {
          Configuration = configuration;
     }

     public IConfiguration Configuration { get; }

     // This method gets called by the runtime. Use this method to add services to the container.
     public void ConfigureServices(IServiceCollection services)
     {
      
      services.AddSingleton(Configuration);
      services.AddDbContext<CampContext>(ServiceLifetime.Scoped)
        .AddIdentity<CampUser, IdentityRole>();
     }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure()
    {
    }
  }
}
